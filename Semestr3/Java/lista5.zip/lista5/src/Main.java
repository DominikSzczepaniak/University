import obliczenia.Wymierna;
import prezentacja.Okno;
import rozgrywka.*;

public class Main {
    public static void main(String[] args){
        /*
        Wymierna x = new Wymierna(1,4);
        Wymierna y = new Wymierna(1, 4);
        Wymierna z = new Wymierna(1, 2);
        if (Wymierna.dodaj(x, y).equals(z))
            System.out.println("nawet nienajgorzej");
        else
            System.out.println("lipa");
         */

        Okno o1 = new Okno();
        o1.setVisible(true);


    }
}
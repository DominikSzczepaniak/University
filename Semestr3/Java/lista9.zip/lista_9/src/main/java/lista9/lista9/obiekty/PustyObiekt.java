package lista9.lista9.obiekty;

public class PustyObiekt extends ObiektNaPlanszy{
}

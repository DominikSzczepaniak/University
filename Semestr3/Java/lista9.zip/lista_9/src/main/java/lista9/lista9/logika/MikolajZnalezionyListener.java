package lista9.lista9.logika;

public interface MikolajZnalezionyListener {
    void znalezionoMikolaja();
}

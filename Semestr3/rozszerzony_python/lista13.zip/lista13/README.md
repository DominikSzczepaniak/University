a) make test
b) make pep8
Uzywalem do Pep8 pakietu autopep8 z Homebrew.
c) make documentation 
d) make typing 
e) nie mam - nie rozumiem co mam zrobic 

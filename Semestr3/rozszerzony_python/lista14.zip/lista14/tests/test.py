import unittest
from src import zad



class DataTests(unittest.TestCase):
    def test_one_data(self):
        zad.add_friend("Jan", "jan@localhost")  
        assert zad.delete_friend(zad.get_friend_id("Jan", "jan@localhost")) == True

    def test_two_data(self):
        zad.add_book("Pan Tadeusz", 1834, "Adam Mickiewicz")
        assert zad.delete_book(zad.get_book_id("Pan Tadeusz", 1834, "Adam Mickiewicz")) == True
    
    def test_three_data(self):
        assert zad.delete_friend(-3) == False


    

class InteractionTests(unittest.TestCase):
    def test_one_interaction(self):
        zad.add_book("Pan Tadeusz", 1834, "Adam Mickiewicz")
        zad.add_friend("Jan", "jan@localhost")
        zad.add_friend("Marek", "marek@localhost")
        assert zad.borrow_book("Jan", "Pan Tadeusz", 1834) == True
        assert zad.borrow_book("Marek", "Pan Tadeusz", 1834) == False
        assert zad.return_book("Marek", "Pan Tadeusz", 1834) == False
        assert zad.return_book("Jan", "Pan Tadeusz", 1834) == True
        zad.delete_friend(zad.get_friend_id("Jan", "jan@localhost"))
        zad.delete_friend(zad.get_friend_id("Marek", "marek@localhost"))
        zad.delete_book(zad.get_book_id("Pan Tadeusz", 1834, "Adam Mickiewicz"))

    def test_two_interaction(self):
        zad.add_book("Pan Tadeusz", 1834, "Adam Mickiewicz")
        zad.add_friend("Jan", "jan@localhost")
        zad.add_friend("Marek", "marek@localhost")
        assert zad.delete_book(zad.get_book_id("Pan Tadeusz", 1834, "Adam Mickiewicz")) == True
        assert zad.borrow_book("Jan", "Pan Tadeusz", 1834) == False
        assert zad.delete_friend(zad.get_friend_id("Jan", "jan@localhost")) == True
        assert zad.delete_friend(zad.get_friend_id("Marek", "marek@localhost")) == True

    def test_three_interaction(self):
        zad.add_book("Pan Tadeusz", 1834, "Adam Mickiewicz")
        zad.add_friend("Jan", "jan@localhost")
        assert zad.delete_friend(zad.get_friend_id("Jan", "jan@localhost")) == True
        zad.list_friends()
        assert zad.borrow_book("Jan", "Pan Tadeusz", 1834) == False
        assert zad.delete_book(zad.get_book_id("Pan Tadeusz", 1834, "Adam Mickiewicz")) == True

class DecoratorTests(unittest.TestCase):
    def test_one_logindecorator(self):
        assert zad.list_books_for_friends(username='admin', password='zle') == False 
    def test_two_logindecorator(self):
        assert zad.list_books_for_friends(username='admin', password='admin') == True 
    
if __name__ == "__main__":
    unittest.main()
import unittest 
from src import zad 
from src.zad import User

    
class TestLoginDecorator(unittest.TestCase):
    def test_not_logged_in(self):
        user = User('admin', 'admin')
        with self.assertRaises(Exception):
            user.add_book('title', 'year', 'author')

    def test_logged_in(self):
        user = User('test', 'test')
        user.is_logged_in = True
        try:
            user.add_book('title', 'year', 'author')
        except Exception:
            self.fail("add_book() raised Exception unexpectedly!")

if __name__ == "__main__":
    unittest.main()